%% Attention alters feature perception
% Jiageng Chen, Andrew Leber & Julie Golomb

% Experiment 1
% code by Jiageng Chen


function runexp()

clear all; close all ; clc
global prm resp

% SyncTest control
choice = questdlg('Test or Experiment?','PreQuestion','Test','Experiment','Experiment');
switch choice
    case 'Test'
        Screen('Preference', 'SkipSyncTests', 1);
    case 'Experiment'
        Screen('Preference', 'SkipSyncTests', 0);
end
%% Miscellaneous
addpath(genpath(pwd)) % add all the subfolder to search path
AssertOpenGL;
prm.quit = 0;

% Key
KbCheck;
KbName('UnifyKeyNames');

% Information input
prm.info = Basic_info;
prm.pref  = Preferences;
s = num2str(round(datevec(now)));
s(s==' ') = '';
prm.info.hash = s;

ListenChar(2);
HideCursor;
%% Open Screen
run OpenScreen;

%% Welcome Screen and Instruction
run WelcomeScreen;


%% Block   
prm.regis.nBlock = 1;
for i = 1:prm.pref.numTri/prm.pref.TperB
    prm.filename.dir = sprintf('data/%s',prm.info.SubIni);
    prm.filename.resp = sprintf('data/%s/block%d_resp_%s.mat',prm.info.SubIni,prm.regis.nBlock,prm.info.hash);
    prm.filename.prm = sprintf('data/%s/block%d_prm_%s.mat',prm.info.SubIni,prm.regis.nBlock,prm.info.hash);
    prm.filename.process = sprintf('data/%s/block%d_resp_%s.txt',prm.info.SubIni,prm.regis.nBlock,prm.info.hash);
    prm.filename.resptxt = sprintf('data/%s/block%d_resptxt_%s.txt',prm.info.SubIni,prm.regis.nBlock,prm.info.hash);
    mkdir(prm.filename.dir);
    prm.file.process = fopen(prm.filename.process,'a');
    prm.file.resptxt = fopen(prm.filename.resptxt,'a');
    fprintf(prm.file.process,'Session Number: %d.\t BlockNumber: %d\n',prm.info.SubNum,prm.regis.nBlock);
    
    if prm.info.EyeTra
        EyelinkSetup(0);
        ET_complete=datestr(now, 13);
        fprintf(prm.file.process,'Calibration complete at: %s; Block %s, Trial %s.\n',ET_complete,num2str(prm.regis.nBlock),num2str(1));
    end
    wordBlock = sprintf('Loading...');
    DrawFormattedText(prm.screen.window,wordBlock,'center','center',255);
    Screen('Flip',prm.screen.window);
    
    run SetRandV;
    BlockStart = GetSecs();
    run RunBlocks;
    BlockEnd = GetSecs();
    resp.time(prm.regis.nBlock) =BlockEnd-BlockStart;
    fprintf(prm.file.process,'The experiment has lasted: %s seconds.\n',num2str(resp.time(prm.regis.nBlock)));
    fprintf(prm.file.process,'Block %s completed.\n',num2str(prm.regis.nBlock));
    prm.regis.nBlock = prm.regis.nBlock+1;
    fclose('all');
    
    %run BlockPerformance
end

%% Close everything
if prm.info.EyeTra
    Eyelink('stoprecording');
    Eyelink('closefile');
    Eyelink('Shutdown'); 
end
Priority(0);
ShowCursor;

WelcomeString = 'Thank you for your participation!!';
DrawFormattedText(prm.screen.window,WelcomeString,'center','center',255);
Screen('Flip',prm.screen.window);
WaitSecs(5);
ListenChar
Screen('CloseAll');
end