function RunBlocks
% run block
global prm

nBlock = prm.regis.nBlock;
wordBlock = sprintf('Block No.%d\n\nPress space to continue',nBlock); 
DrawFormattedText(prm.screen.window,wordBlock,'center','center',0);

Screen('Flip',prm.screen.window);

SpaceNumber=KbName('Space');
[~,keyCode]=KbWait;

while keyCode(SpaceNumber)==0
    [~,keyCode]=KbWait;
end

prm.done = 0;
prm.fixbreakcount = 0;
prm.regis.nTrial = 1;
for i = 1:prm.pref.TperB
    prm.done = 0;
    while ~prm.done
        run RunTrials;
    end  
    prm.regis.nTrial = prm.regis.nTrial+1;
    prm.fixbreakcount = 0;
end

end