function info = Basic_info
% Basic information


% Experiment ID
info.ExperimentID = 'Exo_mixing';
% Date
info.datetime = clock;

% set up question and defaults
n=1;
q{n} = 'Testing Room (A or B)';             defaults{n} = 'A';      n=n+1;
q{n} = 'Subject Initials';                  defaults{n} = 'test';   n=n+1;
q{n} = 'Subject Number';                    defaults{n} = '999';    n=n+1;
q{n} = 'Session Number';                    defaults{n} = '1';      n=n+1;
q{n} = 'NoEyetracker_0 or Eyetracker_1';    defaults{n} = '0';      n=n+1;
q{n} = 'From Block';                        defaults{n} = '1';      n=n+1;
q{n} = 'To Block';                          defaults{n} = '10';


answer = inputdlg(q,'Experimental Setup Information',1,defaults);

% return value
n=1;
info.lab    = answer{n};                n=n+1;
info.SubIni = answer{n};                n=n+1;
info.SubNum = str2double(answer{n});    n=n+1;
info.SesNum = str2double(answer{n});    n=n+1;
info.EyeTra = str2double(answer{n});    n=n+1;
info.FroBlo = str2double(answer{n});    n=n+1;
info.To_Blo = str2double(answer{n});

% return value check
if sum(isnan([info.SubNum,info.SesNum,info.EyeTra,...,
        info.FroBlo,info.To_Blo]))~=0
    errordlg('Please check parameters');
    info = Basic_info;
end

end