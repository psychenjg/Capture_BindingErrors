function WelcomeScreen
% Welcome Screen

global prm

Screen('TextFont',prm.screen.window, 'Arial');
Screen('TextSize',prm.screen.window, 24);

WelcomeString = 'Welcome to our experiment!\n\nPress Space to Continue';
DrawFormattedText(prm.screen.window,WelcomeString,'center','center',255);
Screen('Flip',prm.screen.window);
WaitSecs(0.1);

[~,keyCode]=KbWait(-1);

while keyCode(prm.pref.space)==0
    if keyCode(prm.pref.esc)
        prm.quit = 1;
        break
    end
    [~,keyCode]=KbWait;
end

end
