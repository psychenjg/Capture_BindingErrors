function SetRandV
% set random parameter which changed trial by trial
% generate the specific condition for each trial

% taken codes from make_colorwheel.m & draw_colorwheel.m

global prm

version = 'FourColor';
switch version
    case 'FourColor'
        %% prm.rand
        prm.rand.targetposition = [1 2 3 4];
        % distractcuecondition: 1,same; 2,+90; 3,-90; 0,no
        prm.rand.distractcuecondition = [1 1 2 3 0 0];
        prm.rand.color = [ 0  90 -90 180  1;
                           0  -90 90 180  1;
                           90  0 180 -90  2;
                          -90  0 180  90  2;
                          180 90 -90   0  4;
                          180 -90 90   0  4;
                           90 180  0 -90  3;
                          -90 180  0  90  3];
        %  ---------
        % | 1     2 |
        % |         |
        % | 3     4 |
        %  ---------
        % Combvec
        prm.rand.rotateangle=0:2:359;
        prm.rand.cwflip = [0,1]; % color wheel flip? 0 = original   1 = flip
        %% color wheel
        %color params
        
        % 180 values, circle in CIE L*a*b* space, centered L=70, a=20, b=38, rad=60
        % (from Zhang & Luck, 2008)
        CIEL0=70;
        CIEa0=20;
        CIEb0=38;
        CIErad=60;
        CIEnpts=180;
        
        %define color wheel
        CIEtheta=0:2*pi/CIEnpts:2*pi-2*pi/CIEnpts;
        CIEa=CIErad*cos(CIEtheta)+CIEa0;
        CIEb(1:CIEnpts/2)=sqrt(CIErad^2-(CIEa(1:CIEnpts/2)-CIEa0).^2)+CIEb0;
        CIEb(CIEnpts/2+1:CIEnpts)=-sqrt(CIErad^2-(CIEa(CIEnpts/2+1:CIEnpts)-CIEa0).^2)+CIEb0;
        CIEL=repmat(CIEL0,[1 CIEnpts]);
        
        %convert CIELab wheel to RGB
        %[RGBr RGBg RGBb]=colorspace('Lab->RGB',CIEL,CIEa,CIEb);
        %RGBcolor=[RGBr' RGBg' RGBb']*255;
        
        %better way to convert to RGB
        %CK - UPDATED VALUES FOR EYETRACKING LAB ROOM 312
        if prm.info.lab == 'A'
            color_cali = [.282 .306 96.75]'; %x,y,Y for Testing Room A
        elseif prm.info.lab == 'B'
            color_cali = [.295 .331 89.1]'; %x,y,Y for Testing Room B
        end
        whitexyY=color_cali; %these came from colorimeter for CVCL eyetracking computer
        whiteXYZ = xyYToXYZ(whitexyY);
        XYZ = LabToXYZ([CIEL;CIEa;CIEb],whiteXYZ);
        rgb=XYZToSRGBPrimary(XYZ);
        prm.RGBcolor=SRGBGammaCorrect(rgb)';
        
        maxrad=round(prm.pref.MaxRad*prm.screen.ppd);
        minrad=round(prm.pref.MinRad*prm.screen.ppd);
        angle=2*pi/CIEnpts;
        
        [xx,yy]=meshgrid(-maxrad:maxrad);
        rpix=(xx.^2+yy.^2).^.5; % distance to the center
        theta=atan2(yy,xx);
        theta(theta<0)=theta(theta<0)+ 2*pi;
        %
        %           1.5pi
        %           .   .
        %         .       .
        %       .           .
        %   p  .             . 2pi
        %      .             .  0
        %       .           .
        %         .       .
        %           .   .
        %           0.5pi
        %
        % ***** connection with atan2(y,x) *****
        % angle = mod(2*pi - atan2,2pi)
        % ***** colorRGB matrix *****
        % colorRGB ( ceil(angle*90/pi) )
        % Notice: per color obtain the angle of "pi/90"
        % *************************************************************************
        % from     1         to        180        in RGBmatrix, corresponding to:
        % from [0,pi/90) to [179*pi/90,180*pi/90] in color wheel
        
        wedges=0:angle:2*pi-angle;
        
        prm.stimgrid=repmat(prm.pref.BacCol,[(maxrad*2+1),(maxrad*2+1),3]);
        prm.color_idx_table=zeros(maxrad*2+1);
        
        for i=1:CIEnpts
            if i<CIEnpts
                [wedgeX, wedgeY]=find(rpix>=minrad & rpix<=maxrad & theta>=wedges(i) & theta<wedges(i+1));
            else
                [wedgeX, wedgeY]=find(rpix>=minrad & rpix<=maxrad & theta>=wedges(i));
            end
            prm.stimgrid(wedgeX, wedgeY,1)=prm.RGBcolor(i,1);
            prm.stimgrid(wedgeX, wedgeY,2)=prm.RGBcolor(i,2);
            prm.stimgrid(wedgeX, wedgeY,3)=prm.RGBcolor(i,3);
            prm.color_idx_table(wedgeX,wedgeY)=i;
        end
        prm.color_idx_table_r=zeros(maxrad*2+1);
        prm.stimgrid_r=repmat(prm.pref.BacCol,[(maxrad*2+1),(maxrad*2+1),3]);
        for i=1:CIEnpts
            if i<CIEnpts
                [wedgeX, wedgeY]=find(rpix>=minrad & rpix<=maxrad & theta>=wedges(i) & theta<wedges(i+1));
            else
                [wedgeX, wedgeY]=find(rpix>=minrad & rpix<=maxrad & theta>=wedges(i));
            end
            prm.stimgrid_r(wedgeX, wedgeY,1)=prm.RGBcolor(181-i,1);
            prm.stimgrid_r(wedgeX, wedgeY,2)=prm.RGBcolor(181-i,2);
            prm.stimgrid_r(wedgeX, wedgeY,3)=prm.RGBcolor(181-i,3);
            prm.color_idx_table_r(wedgeX,wedgeY)=181-i;
        end
        %% mask
        % make mask texture (modified from attMix1.m)
        mask=zeros(75,75,3);
        for x=1:75
            for y=1:75
                R=Sample(1:255);
                G=Sample(1:255);
                B=Sample(1:255);
                mask(x,y,1)=R;
                mask(x,y,2)=G;
                mask(x,y,3)=B;
            end
        end
        prm.Texmask=Screen('MakeTexture',prm.screen.window,mask);
        %% prm.trial
        
        for i = 1:prm.pref.TperB
            ii = mod(i,8)+1;
            prm.trial.TargetLocation(i,1) = prm.rand.color(ii,5);
            switch prm.rand.distractcuecondition(mod(i,length(prm.rand.distractcuecondition))+1)
                case 1
                    prm.trial.DistractCueLocation(i,1) = prm.trial.TargetLocation(i,1);
                case 2
                    prm.trial.DistractCueLocation(i,1) = find(prm.rand.color(ii,:) == 90);
                case 3
                    prm.trial.DistractCueLocation(i,1) = find(prm.rand.color(ii,:) == -90);
                case 0
                    prm.trial.DistractCueLocation(i,1) = 0;
            end
            
            prm.trial.colorcondition(i,:) = prm.rand.color(ii,1:4);
            prm.trial.colorIdxseed(i,1) = Randi(180);
            prm.trial.colorIdx(i,1:4) = mod(prm.trial.colorIdxseed(i)+...,
                prm.trial.colorcondition(i,1:4)/2,180);
            prm.trial.colorIdx(i,prm.trial.colorIdx(i,1:4)==0) = 180;
            prm.trial.rotateangle(i,1) = Sample(prm.rand.rotateangle);
            prm.trial.cwflip(i,1) = Sample(prm.rand.cwflip);
            
        end
        try
            t = find(prm.trial.TargetLocation == 1 & prm.trial.DistractCueLocation == 2);
            prm.trial.DistractCueLocation(t(1)) = 3;
            t = find(prm.trial.TargetLocation == 2 & prm.trial.DistractCueLocation == 1);
            prm.trial.DistractCueLocation(t(1)) = 4;
            t = find(prm.trial.TargetLocation == 3 & prm.trial.DistractCueLocation == 1);
            prm.trial.DistractCueLocation(t(1)) = 4;
            t = find(prm.trial.TargetLocation == 4 & prm.trial.DistractCueLocation == 2);
            prm.trial.DistractCueLocation(t(1)) = 3;
        catch
        end
    case 'ThreeColor'
        %% Stimuli: Three color, 30, 90degree
        %% prm.rand
        prm.rand.precueposition = [1 2 3 4];
        prm.rand.rescuecondition = 1:24;
        prm.rand.color_diff_table = ...,
            [ 0  90 -90  1 1;
              0 -90  90  1 2;
             90   0 -90  2 3;
            -90   0  90  2 4;
             90 -90   0  3 5;
            -90  90   0  3 6;
              0  30 -30  1 7;
              0 -30  30  1 8;
             30   0 -30  2 9;
            -30   0  30  2 10;
             30 -30   0  3 11;
            -30  30   0  3 12;
            
              0  30 -90  1 13;
              0 -90  30  1 14;
             30   0 -90  2 15;
            -90   0  30  2 16;
             30 -90   0  3 17;
            -90  30   0  3 18;
              0  90 -30  1 19;
              0 -30  90  1 20;
             90   0 -30  2 21;
            -30   0  90  2 22;
             90 -30   0  3 23;
            -30  90   0  3 24;
            ]; % color of position 1 2 3, rescueposition, condition
        %  ---------
        % |    1    |
        % |         |
        % | 2     3 |
        %  ---------
        % Combvec
        prm.rand.pre_res = CombVec(prm.rand.precueposition,prm.rand.rescuecondition)';
        prm.rand.howmanycopy = prm.pref.TperB/length(prm.rand.pre_res);
        prm.rand.rotateangle=0:2:359;
        prm.rand.cwflip = [0,1]; % color wheel flip? 0 = original   1 = flip
        %% color wheel
        %color params
        
        % 180 values, circle in CIE L*a*b* space, centered L=70, a=20, b=38, rad=60
        % (from Zhang & Luck, 2008)
        CIEL0=70;
        CIEa0=20;
        CIEb0=38;
        CIErad=60;
        CIEnpts=180;
        
        %define color wheel
        CIEtheta=0:2*pi/CIEnpts:2*pi-2*pi/CIEnpts;
        CIEa=CIErad*cos(CIEtheta)+CIEa0;
        CIEb(1:CIEnpts/2)=sqrt(CIErad^2-(CIEa(1:CIEnpts/2)-CIEa0).^2)+CIEb0;
        CIEb(CIEnpts/2+1:CIEnpts)=-sqrt(CIErad^2-(CIEa(CIEnpts/2+1:CIEnpts)-CIEa0).^2)+CIEb0;
        CIEL=repmat(CIEL0,[1 CIEnpts]);
        
        %convert CIELab wheel to RGB
        %[RGBr RGBg RGBb]=colorspace('Lab->RGB',CIEL,CIEa,CIEb);
        %RGBcolor=[RGBr' RGBg' RGBb']*255;
        
        %better way to convert to RGB
        %CK - UPDATED VALUES FOR EYETRACKING LAB ROOM 312
        if prm.info.lab == 'A'
            color_cali = [.282 .306 96.75]'; %x,y,Y for Testing Room A
        elseif prm.info.lab == 'B'
            color_cali = [.295 .331 89.1]'; %x,y,Y for Testing Room B
        end
        whitexyY=color_cali; %these came from colorimeter for CVCL eyetracking computer
        whiteXYZ = xyYToXYZ(whitexyY);
        XYZ = LabToXYZ([CIEL;CIEa;CIEb],whiteXYZ);
        rgb=XYZToSRGBPrimary(XYZ);
        prm.RGBcolor=SRGBGammaCorrect(rgb)';
        
        maxrad=round(prm.pref.MaxRad*prm.screen.ppd);
        minrad=round(prm.pref.MinRad*prm.screen.ppd);
        angle=2*pi/CIEnpts;
        
        [xx,yy]=meshgrid(-maxrad:maxrad);
        rpix=(xx.^2+yy.^2).^.5; % distance to the center
        theta=atan2(yy,xx);
        theta(theta<0)=theta(theta<0)+ 2*pi;
        %
        %           1.5pi
        %           .   .
        %         .       .
        %       .           .
        %   p  .             . 2pi
        %      .             .  0
        %       .           .
        %         .       .
        %           .   .
        %           0.5pi
        %
        % ***** connection with atan2(y,x) *****
        % angle = mod(2*pi - atan2,2pi)
        % ***** colorRGB matrix *****
        % colorRGB ( ceil(angle*90/pi) )
        % Notice: per color obtain the angle of "pi/90"
        % *************************************************************************
        % from     1         to        180        in RGBmatrix, corresponding to:
        % from [0,pi/90) to [179*pi/90,180*pi/90] in color wheel
        
        wedges=0:angle:2*pi-angle;
        
        prm.stimgrid=repmat(prm.pref.BacCol,[(maxrad*2+1),(maxrad*2+1),3]);
        prm.color_idx_table=zeros(maxrad*2+1);
        
        for i=1:CIEnpts
            if i<CIEnpts
                [wedgeX, wedgeY]=find(rpix>=minrad & rpix<=maxrad & theta>=wedges(i) & theta<wedges(i+1));
            else
                [wedgeX, wedgeY]=find(rpix>=minrad & rpix<=maxrad & theta>=wedges(i));
            end
            prm.stimgrid(wedgeX, wedgeY,1)=prm.RGBcolor(i,1);
            prm.stimgrid(wedgeX, wedgeY,2)=prm.RGBcolor(i,2);
            prm.stimgrid(wedgeX, wedgeY,3)=prm.RGBcolor(i,3);
            prm.color_idx_table(wedgeX,wedgeY)=i;
        end
        prm.color_idx_table_r=zeros(maxrad*2+1);
        prm.stimgrid_r=repmat(prm.pref.BacCol,[(maxrad*2+1),(maxrad*2+1),3]);
        for i=1:CIEnpts
            if i<CIEnpts
                [wedgeX, wedgeY]=find(rpix>=minrad & rpix<=maxrad & theta>=wedges(i) & theta<wedges(i+1));
            else
                [wedgeX, wedgeY]=find(rpix>=minrad & rpix<=maxrad & theta>=wedges(i));
            end
            prm.stimgrid_r(wedgeX, wedgeY,1)=prm.RGBcolor(181-i,1);
            prm.stimgrid_r(wedgeX, wedgeY,2)=prm.RGBcolor(181-i,2);
            prm.stimgrid_r(wedgeX, wedgeY,3)=prm.RGBcolor(181-i,3);
            prm.color_idx_table_r(wedgeX,wedgeY)=181-i;
        end
        %% mask
        % make mask texture (modified from attMix1.m)
        mask=zeros(75,75,3);
        for x=1:75
            for y=1:75
                R=Sample(1:255);
                G=Sample(1:255);
                B=Sample(1:255);
                mask(x,y,1)=R;
                mask(x,y,2)=G;
                mask(x,y,3)=B;
            end
        end
        prm.Texmask=Screen('MakeTexture',prm.screen.window,mask);
        %% prm.trial
        prm.trial.lookup = repmat(prm.rand.pre_res,prm.rand.howmanycopy,1);
        
        for i = 1:prm.pref.TperB
            
            prm.trial.precueposition0(i,1) = prm.trial.lookup(i,1);
            prm.trial.rescueposition0(i,1) = prm.rand.color_diff_table(...,
                prm.rand.color_diff_table(:,5)==prm.trial.lookup(i,2),4);
            prm.trial.colorcondition0(i,:) = prm.rand.color_diff_table(...,
                prm.rand.color_diff_table(:,5)==prm.trial.lookup(i,2),1:3);
            prm.trial.colorIdxseed0(i,1) = Randi(180);
            prm.trial.colorIdx0(i,1:3) = mod(prm.trial.colorIdxseed0(i)+...,
                prm.trial.colorcondition0(i,1:3)/2,180);
            prm.trial.colorIdx0(i,prm.trial.colorIdx0(i,1:3)==0) = 180;
            prm.trial.rotateangle0(i,1) = Sample(prm.rand.rotateangle);
            prm.trial.cwflip0(i,1) = Sample(prm.rand.cwflip);
            
        end
        shuf = Shuffle(1:prm.pref.TperB);
        for i = 1:prm.pref.TperB
            prm.trial.precueposition(i,1) = prm.trial.precueposition0(shuf(i));
            prm.trial.rescueposition(i,1)=prm.trial.rescueposition0(shuf(i));
            prm.trial.colorcondition(i,1:3)=prm.trial.colorcondition0(shuf(i),:);
            prm.trial.colorIdxseed(i,1)=prm.trial.colorIdxseed0(shuf(i));
            prm.trial.colorIdx(i,1:3)=prm.trial.colorIdx0(shuf(i),1:3);
            prm.trial.rotateangle(i,1)=prm.trial.rotateangle0(shuf(i));
            prm.trial.cwflip(i,1)=prm.trial.cwflip0(shuf(i));
        end
    case 'ThreeColor9090'
        %% Stimuli: Three color, 90degree
        %% prm.rand
        prm.rand.precueposition = [1 2 3 4];
        prm.rand.rescuecondition = 1:6;
        prm.rand.color_diff_table = ...,
            [ 0  90 -90  1 1;
              0 -90  90  1 2;
             90   0 -90  2 3;
            -90   0  90  2 4;
             90 -90   0  3 5;
            -90  90   0  3 6;
              
            ]; % color of position 1 2 3, rescueposition, condition
        %  ---------
        % |    1    |
        % |         |
        % | 2     3 |
        %  ---------
        % Combvec
        prm.rand.pre_res = CombVec(prm.rand.precueposition,prm.rand.rescuecondition)';
        prm.rand.howmanycopy = prm.pref.TperB/length(prm.rand.pre_res);
        prm.rand.rotateangle=0:2:359;
        prm.rand.cwflip = [0,1]; % color wheel flip? 0 = original   1 = flip
        %% color wheel
        %color params
        
        % 180 values, circle in CIE L*a*b* space, centered L=70, a=20, b=38, rad=60
        % (from Zhang & Luck, 2008)
        CIEL0=70;
        CIEa0=20;
        CIEb0=38;
        CIErad=60;
        CIEnpts=180;
        
        %define color wheel
        CIEtheta=0:2*pi/CIEnpts:2*pi-2*pi/CIEnpts;
        CIEa=CIErad*cos(CIEtheta)+CIEa0;
        CIEb(1:CIEnpts/2)=sqrt(CIErad^2-(CIEa(1:CIEnpts/2)-CIEa0).^2)+CIEb0;
        CIEb(CIEnpts/2+1:CIEnpts)=-sqrt(CIErad^2-(CIEa(CIEnpts/2+1:CIEnpts)-CIEa0).^2)+CIEb0;
        CIEL=repmat(CIEL0,[1 CIEnpts]);
        
        %convert CIELab wheel to RGB
        %[RGBr RGBg RGBb]=colorspace('Lab->RGB',CIEL,CIEa,CIEb);
        %RGBcolor=[RGBr' RGBg' RGBb']*255;
        
        %better way to convert to RGB
        %CK - UPDATED VALUES FOR EYETRACKING LAB ROOM 312
        if prm.info.lab == 'A'
            color_cali = [.282 .306 96.75]'; %x,y,Y for Testing Room A
        elseif prm.info.lab == 'B'
            color_cali = [.295 .331 89.1]'; %x,y,Y for Testing Room B
        end
        whitexyY=color_cali; %these came from colorimeter for CVCL eyetracking computer
        whiteXYZ = xyYToXYZ(whitexyY);
        XYZ = LabToXYZ([CIEL;CIEa;CIEb],whiteXYZ);
        rgb=XYZToSRGBPrimary(XYZ);
        prm.RGBcolor=SRGBGammaCorrect(rgb)';
        
        maxrad=round(prm.pref.MaxRad*prm.screen.ppd);
        minrad=round(prm.pref.MinRad*prm.screen.ppd);
        angle=2*pi/CIEnpts;
        
        [xx,yy]=meshgrid(-maxrad:maxrad);
        rpix=(xx.^2+yy.^2).^.5; % distance to the center
        theta=atan2(yy,xx);
        theta(theta<0)=theta(theta<0)+ 2*pi;
        %
        %           1.5pi
        %           .   .
        %         .       .
        %       .           .
        %   p  .             . 2pi
        %      .             .  0
        %       .           .
        %         .       .
        %           .   .
        %           0.5pi
        %
        % ***** connection with atan2(y,x) *****
        % angle = mod(2*pi - atan2,2pi)
        % ***** colorRGB matrix *****
        % colorRGB ( ceil(angle*90/pi) )
        % Notice: per color obtain the angle of "pi/90"
        % *************************************************************************
        % from     1         to        180        in RGBmatrix, corresponding to:
        % from [0,pi/90) to [179*pi/90,180*pi/90] in color wheel
        
        wedges=0:angle:2*pi-angle;
        
        prm.stimgrid=repmat(prm.pref.BacCol,[(maxrad*2+1),(maxrad*2+1),3]);
        prm.color_idx_table=zeros(maxrad*2+1);
        
        for i=1:CIEnpts
            if i<CIEnpts
                [wedgeX, wedgeY]=find(rpix>=minrad & rpix<=maxrad & theta>=wedges(i) & theta<wedges(i+1));
            else
                [wedgeX, wedgeY]=find(rpix>=minrad & rpix<=maxrad & theta>=wedges(i));
            end
            prm.stimgrid(wedgeX, wedgeY,1)=prm.RGBcolor(i,1);
            prm.stimgrid(wedgeX, wedgeY,2)=prm.RGBcolor(i,2);
            prm.stimgrid(wedgeX, wedgeY,3)=prm.RGBcolor(i,3);
            prm.color_idx_table(wedgeX,wedgeY)=i;
        end
        prm.color_idx_table_r=zeros(maxrad*2+1);
        prm.stimgrid_r=repmat(prm.pref.BacCol,[(maxrad*2+1),(maxrad*2+1),3]);
        for i=1:CIEnpts
            if i<CIEnpts
                [wedgeX, wedgeY]=find(rpix>=minrad & rpix<=maxrad & theta>=wedges(i) & theta<wedges(i+1));
            else
                [wedgeX, wedgeY]=find(rpix>=minrad & rpix<=maxrad & theta>=wedges(i));
            end
            prm.stimgrid_r(wedgeX, wedgeY,1)=prm.RGBcolor(181-i,1);
            prm.stimgrid_r(wedgeX, wedgeY,2)=prm.RGBcolor(181-i,2);
            prm.stimgrid_r(wedgeX, wedgeY,3)=prm.RGBcolor(181-i,3);
            prm.color_idx_table_r(wedgeX,wedgeY)=181-i;
        end
        %% mask
        % make mask texture (modified from attMix1.m)
        mask=zeros(75,75,3);
        for x=1:75
            for y=1:75
                R=Sample(1:255);
                G=Sample(1:255);
                B=Sample(1:255);
                mask(x,y,1)=R;
                mask(x,y,2)=G;
                mask(x,y,3)=B;
            end
        end
        prm.Texmask=Screen('MakeTexture',prm.screen.window,mask);
        %% prm.trial
        prm.trial.lookup = repmat(prm.rand.pre_res,prm.rand.howmanycopy,1);
        
        for i = 1:prm.pref.TperB
            
            prm.trial.precueposition0(i,1) = prm.trial.lookup(i,1);
            prm.trial.rescueposition0(i,1) = prm.rand.color_diff_table(...,
                prm.rand.color_diff_table(:,5)==prm.trial.lookup(i,2),4);
            prm.trial.colorcondition0(i,:) = prm.rand.color_diff_table(...,
                prm.rand.color_diff_table(:,5)==prm.trial.lookup(i,2),1:3);
            prm.trial.colorIdxseed0(i,1) = Randi(180);
            prm.trial.colorIdx0(i,1:3) = mod(prm.trial.colorIdxseed0(i)+...,
                prm.trial.colorcondition0(i,1:3)/2,180);
            prm.trial.colorIdx0(i,prm.trial.colorIdx0(i,1:3)==0) = 180;
            prm.trial.rotateangle0(i,1) = Sample(prm.rand.rotateangle);
            prm.trial.cwflip0(i,1) = Sample(prm.rand.cwflip);
            
        end
        shuf = Shuffle(1:prm.pref.TperB);
        for i = 1:prm.pref.TperB
            prm.trial.precueposition(i,1) = prm.trial.precueposition0(shuf(i));
            prm.trial.rescueposition(i,1)=prm.trial.rescueposition0(shuf(i));
            prm.trial.colorcondition(i,1:3)=prm.trial.colorcondition0(shuf(i),:);
            prm.trial.colorIdxseed(i,1)=prm.trial.colorIdxseed0(shuf(i));
            prm.trial.colorIdx(i,1:3)=prm.trial.colorIdx0(shuf(i),1:3);
            prm.trial.rotateangle(i,1)=prm.trial.rotateangle0(shuf(i));
            prm.trial.cwflip(i,1)=prm.trial.cwflip0(shuf(i));
        end        
end

end