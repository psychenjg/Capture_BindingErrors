function p = Preferences
% setup preferences for this experiment

%% Study
p.StudyName = 'Exo_mixing';
%% Key
p.space = KbName('Space');
p.esc = KbName('Escape');
p.quitkey = KbName('q');

%% Screen
p.BacCol = 255/2; % background color
%% Stimuli
p.ColSiz = 2;    % color patch size (side length) : X degree. pixel = p.ColSiz * ppd
p.CueSiz = 2;    % cue size: X degree.
p.CueCol = 255;  % cue color
p.CueColgray = 255/3;
p.Eccent = 3;
% if the number of color patches is 4, p.Eccent means the distance from
% fixation to the center of each patch (oblique line)
p.CueEcc = p.Eccent;
p.CueWid = 0.2;
p.HolWid = 0.08;  % location holder of color square
p.FixSiz = .3;  
p.FixCol = 255;  % fixation color
p.MaxRad = 7;
p.MinRad = p.MaxRad*0.8;

p.dotDist = 0.4; % distractor dot to the color edge
%% Duration
p.FixDur = 0.3;  % fixation duration
p.CueDur = 0.1;  % cue duration
p.ISI1   = 0.1;  % ISI 1
p.CorDur = 0.05; % color
p.ISI2   = 0.1;    % ISI 2
p.MasDur = 0.2;  % mask
p.FeeDur = 0.5;    % feedback
p.ITI    = 0.4;    % ITI
p.EasyCorDur = 0.5;
%% Block & Trial
p.numTri = 48*10;
p.TperB  = 48;

%% Eye-tracking parameter
p.PrepareTime = p.FixDur/2;
p.max_prefix_time=2;
p.fixlossradVA = 1.5; % degree
p.fixlosscount_thresh=4; % threshold for each trial


end