function RunBlocks
% run block
global prm

nBlock = prm.regis.nBlock;
wordBlock = sprintf('Block No.%d\n\nPress space to continue',nBlock); 
DrawFormattedText(prm.screen.window,wordBlock,'center','center',0);

Screen('Flip',prm.screen.window);

SpaceNumber=KbName('Space');
WaitSecs(0.01);
[~,keyCode]=KbWait(-1);
while keyCode(SpaceNumber)==0
    [~,keyCode]=KbWait(-1);
end

prm.done = 0;
prm.fixbreakcount = 0;
prm.regis.nTrial = 1;
for i = 1:prm.pref.TperB
    prm.done = 0;
    while ~prm.done
        run RunTrials;
    end  
    prm.regis.nTrial = prm.regis.nTrial+1;
    prm.fixbreakcount = 0;
end

end