function OpenScreen
% function to Open screen
global prm 

% open window
whichscreen = max(Screen('Screens'));
[prm.screen.window,prm.screen.rect] = Screen('OpenWindow',whichscreen,prm.pref.BacCol);
Screen(prm.screen.window,'BlendFunction',GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
Priority(MaxPriority(prm.screen.window));
Screen('Flip',prm.screen.window);

% monitor dimensions and center
prm.screen.monitor = Screen(prm.screen.window,'Resolution');
[prm.screen.center(1),prm.screen.center(2)] = RectCenter(prm.screen.rect);
prm.screen.refresh = Screen('GetFlipInterval',prm.screen.window);

% viewing parameter
prm.screen.v_dist = 60;   % viewing distance (cm)
prm.screen.mon_width = 39;   % horizontal dimension of viewable screen (cm)

%Pixels per degree
prm.screen.ppd = pi * (prm.screen.rect(3)-prm.screen.rect(1)) / atan(prm.screen.mon_width/prm.screen.v_dist/2) / 360;

end
