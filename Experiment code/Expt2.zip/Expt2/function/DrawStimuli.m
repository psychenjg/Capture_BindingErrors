function DrawStimuli(phase)
% draw stimuli
% need to flip after calling this function

global prm resp
switch phase
    case 'Fixation'
        % fixation
        rectSize = prm.pref.FixSiz*prm.screen.ppd; % fixation size
        rectSize_ = rectSize./5;
%         rectFix = [prm.screen.center(1)-rectSize/2,...,
%             prm.screen.center(2)-rectSize/2,...,
%             prm.screen.center(1)+rectSize/2,...,
%             prm.screen.center(2)+rectSize/2];
%         Screen('FillOval',prm.screen.window,prm.pref.FixCol,rectFix);
        
        fixationlocation1 = CenterRectOnPoint([0 0 rectSize rectSize_],prm.screen.center(1),prm.screen.center(2)); % --
        fixationlocation1_ = CenterRectOnPoint([0 0 rectSize_ rectSize],prm.screen.center(1),prm.screen.center(2)); % |
        
            
        
        Screen('FillRect',prm.screen.window,prm.pref.FixCol,fixationlocation1);
        Screen('FillRect',prm.screen.window,prm.pref.FixCol,fixationlocation1_);

        
    case 'PreCue4'
        % exogenous cue
        cueSize = prm.pref.CueSiz*prm.screen.ppd;
        cueEcc  = prm.pref.CueEcc*prm.screen.ppd;
        cueWid  = prm.pref.CueWid*prm.screen.ppd;
        %  ---------
        % | 1     2 |
        % |         |
        % | 3     4 |
        %  ---------
        rectCue1 = [prm.screen.center(1)-cueEcc/sqrt(2)-cueSize/2,...,
            prm.screen.center(2)-cueEcc/sqrt(2)-cueSize/2,...,
            prm.screen.center(1)-cueEcc/sqrt(2)+cueSize/2,...,
            prm.screen.center(2)-cueEcc/sqrt(2)+cueSize/2];
        rectCue2 = [prm.screen.center(1)+cueEcc/sqrt(2)-cueSize/2,...,
            prm.screen.center(2)-cueEcc/sqrt(2)-cueSize/2,...,
            prm.screen.center(1)+cueEcc/sqrt(2)+cueSize/2,...,
            prm.screen.center(2)-cueEcc/sqrt(2)+cueSize/2];
        rectCue3 = [prm.screen.center(1)-cueEcc/sqrt(2)-cueSize/2,...,
            prm.screen.center(2)+cueEcc/sqrt(2)-cueSize/2,...,
            prm.screen.center(1)-cueEcc/sqrt(2)+cueSize/2,...,
            prm.screen.center(2)+cueEcc/sqrt(2)+cueSize/2];
        rectCue4 = [prm.screen.center(1)+cueEcc/sqrt(2)-cueSize/2,...,
            prm.screen.center(2)+cueEcc/sqrt(2)-cueSize/2,...,
            prm.screen.center(1)+cueEcc/sqrt(2)+cueSize/2,...,
            prm.screen.center(2)+cueEcc/sqrt(2)+cueSize/2];
        switch prm.regis.TargetLocation
            case 1
                Screen('FrameRect',prm.screen.window,prm.pref.CueCol,rectCue1,cueWid);
            case 2
                Screen('FrameRect',prm.screen.window,prm.pref.CueCol,rectCue2,cueWid);
            case 3
                Screen('FrameRect',prm.screen.window,prm.pref.CueCol,rectCue3,cueWid);
            case 4
                Screen('FrameRect',prm.screen.window,prm.pref.CueCol,rectCue4,cueWid);
        end
    case 'ColorPatch4'
        % color square
        %  ---------
        % | 1     2 |
        % |         |
        % | 3     4 |
        %  ---------
        colorSize  = prm.pref.ColSiz * prm.screen.ppd;
        colorEcc   = prm.pref.Eccent * prm.screen.ppd;
        color1     = prm.regis.colorsquare1;
        color2     = prm.regis.colorsquare2;
        color3     = prm.regis.colorsquare3;
        color4     = prm.regis.colorsquare4;
        rectColor1 = [prm.screen.center(1)-colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(2)-colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(1)-colorEcc/sqrt(2)+colorSize/2,...,
            prm.screen.center(2)-colorEcc/sqrt(2)+colorSize/2];
        rectColor2 = [prm.screen.center(1)+colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(2)-colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(1)+colorEcc/sqrt(2)+colorSize/2,...,
            prm.screen.center(2)-colorEcc/sqrt(2)+colorSize/2];
        rectColor3 = [prm.screen.center(1)-colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(2)+colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(1)-colorEcc/sqrt(2)+colorSize/2,...,
            prm.screen.center(2)+colorEcc/sqrt(2)+colorSize/2];
        rectColor4 = [prm.screen.center(1)+colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(2)+colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(1)+colorEcc/sqrt(2)+colorSize/2,...,
            prm.screen.center(2)+colorEcc/sqrt(2)+colorSize/2];
        Screen('FillRect',prm.screen.window,color1,rectColor1);
        Screen('FillRect',prm.screen.window,color2,rectColor2);
        Screen('FillRect',prm.screen.window,color3,rectColor3);
        Screen('FillRect',prm.screen.window,color4,rectColor4);
    case 'Mask4'
        % mask
        colorSize  = prm.pref.ColSiz * prm.screen.ppd;
        colorEcc   = prm.pref.Eccent * prm.screen.ppd;
        rectColor1 = [prm.screen.center(1)-colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(2)-colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(1)-colorEcc/sqrt(2)+colorSize/2,...,
            prm.screen.center(2)-colorEcc/sqrt(2)+colorSize/2];
        rectColor2 = [prm.screen.center(1)+colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(2)-colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(1)+colorEcc/sqrt(2)+colorSize/2,...,
            prm.screen.center(2)-colorEcc/sqrt(2)+colorSize/2];
        rectColor3 = [prm.screen.center(1)-colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(2)+colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(1)-colorEcc/sqrt(2)+colorSize/2,...,
            prm.screen.center(2)+colorEcc/sqrt(2)+colorSize/2];
        rectColor4 = [prm.screen.center(1)+colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(2)+colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(1)+colorEcc/sqrt(2)+colorSize/2,...,
            prm.screen.center(2)+colorEcc/sqrt(2)+colorSize/2];
        Screen('DrawTexture',prm.screen.window,prm.Texmask,[],rectColor1);
        Screen('DrawTexture',prm.screen.window,prm.Texmask,[],rectColor2);
        Screen('DrawTexture',prm.screen.window,prm.Texmask,[],rectColor3);
        Screen('DrawTexture',prm.screen.window,prm.Texmask,[],rectColor4);
    case 'RespCue4'
        % responsecue
        colorSize  = prm.pref.ColSiz * prm.screen.ppd;
        colorEcc   = prm.pref.Eccent * prm.screen.ppd;
        cueWid     = prm.pref.CueWid * prm.screen.ppd;
        rectColor1 = [prm.screen.center(1)-colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(2)-colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(1)-colorEcc/sqrt(2)+colorSize/2,...,
            prm.screen.center(2)-colorEcc/sqrt(2)+colorSize/2];
        rectColor2 = [prm.screen.center(1)+colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(2)-colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(1)+colorEcc/sqrt(2)+colorSize/2,...,
            prm.screen.center(2)-colorEcc/sqrt(2)+colorSize/2];
        rectColor3 = [prm.screen.center(1)-colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(2)+colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(1)-colorEcc/sqrt(2)+colorSize/2,...,
            prm.screen.center(2)+colorEcc/sqrt(2)+colorSize/2];
        rectColor4 = [prm.screen.center(1)+colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(2)+colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(1)+colorEcc/sqrt(2)+colorSize/2,...,
            prm.screen.center(2)+colorEcc/sqrt(2)+colorSize/2];
        switch prm.regis.TargetLocation 
            %  ---------
            % | 1     2 |
            % |         |
            % | 3     4 |
            %  ---------
            case 1
                Screen('FrameRect',prm.screen.window,prm.pref.CueCol,rectColor1,cueWid);
            case 2
                Screen('FrameRect',prm.screen.window,prm.pref.CueCol,rectColor2,cueWid);
            case 3
                Screen('FrameRect',prm.screen.window,prm.pref.CueCol,rectColor3,cueWid);
            case 4
                Screen('FrameRect',prm.screen.window,prm.pref.CueCol,rectColor4,cueWid);
        end
    case 'ColorWheel'
        % color wheel
        if ~prm.regis.cwflip
            tex=Screen('MakeTexture',prm.screen.window,prm.stimgrid);
        else
            tex=Screen('MakeTexture',prm.screen.window,prm.stimgrid_r);
        end
        blur=5; % put gray circle over edges to blur roughness
        maxrad=round(prm.pref.MaxRad*prm.screen.ppd);
        minrad=round(prm.pref.MinRad*prm.screen.ppd);
        Screen('DrawTexture',prm.screen.window,tex,[],[],prm.regis.rotateangle);
        Screen('FrameOval',prm.screen.window,prm.pref.BacCol,...,
            [prm.screen.center(1)-maxrad-blur ...,
            prm.screen.center(2)-maxrad-blur...,
            prm.screen.center(1)+maxrad+blur...,
            prm.screen.center(2)+maxrad+blur],blur);
        Screen('FrameOval',prm.screen.window,prm.pref.BacCol,...,
            [prm.screen.center(1)-minrad...,
            prm.screen.center(2)-minrad...,
            prm.screen.center(1)+minrad...,
            prm.screen.center(2)+minrad],blur);
        Screen('Close',tex);
    case 'ShadedOval'
        shaded=15; % put gray circle over edges to blur roughness
        targetcolorIdx = resp.clickrange1.colorIdx(prm.regis.nTrial);
        if ~prm.regis.cwflip
            theta = 360-mod(targetcolorIdx*2-1 + prm.regis.rotateangle,360);
            startAngle(1) = theta;
        else
            theta = 360-mod((181-targetcolorIdx)*2-1 + prm.regis.rotateangle,360);
            startAngle(1) = theta;
        end
        targetcolorIdx = prm.regis.currentColor;
        if ~prm.regis.cwflip
            theta = 360-mod(targetcolorIdx*2-1 + prm.regis.rotateangle,360);
            startAngle(2) = theta;
        else
            theta = 360-mod((181-targetcolorIdx)*2-1 + prm.regis.rotateangle,360);
            startAngle(2) = theta;
        end
        startAngle(1) = mod(-startAngle(1)+90,360)-1;
        startAngle(2) = mod(-startAngle(2)+90,360); 
        startAngle(2) = mod(startAngle(2)-startAngle(1),360)+1;
        maxrad=round(prm.pref.MaxRad*prm.screen.ppd);
        minrad=round(prm.pref.MinRad*prm.screen.ppd);
        Screen('FrameArc',prm.screen.window,0,...,
            [prm.screen.center(1)-minrad ...,
            prm.screen.center(2)-minrad...,
            prm.screen.center(1)+minrad...,
            prm.screen.center(2)+minrad],startAngle(1),startAngle(2),shaded);
        Screen('FrameArc',prm.screen.window,0,...,
            [prm.screen.center(1)-maxrad-shaded ...,
            prm.screen.center(2)-maxrad-shaded...,
            prm.screen.center(1)+maxrad+shaded...,
            prm.screen.center(2)+maxrad+shaded],startAngle(1),startAngle(2),shaded);
    case 'FeedLine'
        % draw feedback line
        targetcolorIdx = prm.regis.colortargetIdx;
        minr = round(prm.pref.MinRad*prm.screen.ppd)-5;
        maxr = round(prm.pref.MaxRad*prm.screen.ppd)+5;
        if ~prm.regis.cwflip % no flip
            
            theta = 360-mod(targetcolorIdx*2-1 + prm.regis.rotateangle,360);
            fromH = prm.screen.center(1) + minr*cos(theta/180*pi);
            fromV = prm.screen.center(2) - minr*sin(theta/180*pi);
            toH   = prm.screen.center(1) + maxr*cos(theta/180*pi);
            toV   = prm.screen.center(2) - maxr*sin(theta/180*pi);
        else
            
            theta = 360-mod((181-targetcolorIdx)*2-1 + prm.regis.rotateangle,360);
            fromH = prm.screen.center(1) + minr*cos(theta/180*pi);
            fromV = prm.screen.center(2) - minr*sin(theta/180*pi);
            toH   = prm.screen.center(1) + maxr*cos(theta/180*pi);
            toV   = prm.screen.center(2) - maxr*sin(theta/180*pi);
        end
        
        Screen('DrawLine',prm.screen.window,0,fromH,fromV,toH,toV,3);
    case 'Line'
        % draw feedback line
        targetcolorIdx = prm.regis.currentColor;
        
        
        minr = round(prm.pref.MinRad*prm.screen.ppd)-10;
        maxr = round(prm.pref.MaxRad*prm.screen.ppd)+10;
        if ~prm.regis.cwflip % no flip
            
            theta = 360-mod(targetcolorIdx*2-1 + prm.regis.rotateangle,360);
            fromH = prm.screen.center(1) + minr*cos(theta/180*pi);
            fromV = prm.screen.center(2) - minr*sin(theta/180*pi);
            toH   = prm.screen.center(1) + maxr*cos(theta/180*pi);
            toV   = prm.screen.center(2) - maxr*sin(theta/180*pi);
        else
            
            theta = 360-mod((181-targetcolorIdx)*2-1 + prm.regis.rotateangle,360);
            fromH = prm.screen.center(1) + minr*cos(theta/180*pi);
            fromV = prm.screen.center(2) - minr*sin(theta/180*pi);
            toH   = prm.screen.center(1) + maxr*cos(theta/180*pi);
            toV   = prm.screen.center(2) - maxr*sin(theta/180*pi);
        end
        Screen('DrawLine',prm.screen.window,0,fromH,fromV,toH,toV,3);    
    case 'Holder4'
        % draw square holder
        cueSize = prm.pref.CueSiz*prm.screen.ppd;
        cueEcc  = prm.pref.CueEcc*prm.screen.ppd;
        holdWid = prm.pref.HolWid*prm.screen.ppd;
        %  ---------
        % | 1     2 |
        % |         |
        % | 3     4 |
        %  ---------
        
        rectCue1 = [prm.screen.center(1)-cueEcc/sqrt(2)-cueSize/2,...,
            prm.screen.center(2)-cueEcc/sqrt(2)-cueSize/2,...,
            prm.screen.center(1)-cueEcc/sqrt(2)+cueSize/2,...,
            prm.screen.center(2)-cueEcc/sqrt(2)+cueSize/2];
        
        rectCue2 = [prm.screen.center(1)+cueEcc/sqrt(2)-cueSize/2,...,
            prm.screen.center(2)-cueEcc/sqrt(2)-cueSize/2,...,
            prm.screen.center(1)+cueEcc/sqrt(2)+cueSize/2,...,
            prm.screen.center(2)-cueEcc/sqrt(2)+cueSize/2];
        
        rectCue3 = [prm.screen.center(1)-cueEcc/sqrt(2)-cueSize/2,...,
            prm.screen.center(2)+cueEcc/sqrt(2)-cueSize/2,...,
            prm.screen.center(1)-cueEcc/sqrt(2)+cueSize/2,...,
            prm.screen.center(2)+cueEcc/sqrt(2)+cueSize/2];
        
        rectCue4 = [prm.screen.center(1)+cueEcc/sqrt(2)-cueSize/2,...,
            prm.screen.center(2)+cueEcc/sqrt(2)-cueSize/2,...,
            prm.screen.center(1)+cueEcc/sqrt(2)+cueSize/2,...,
            prm.screen.center(2)+cueEcc/sqrt(2)+cueSize/2];
        
        Screen('FrameRect',prm.screen.window,prm.pref.CueCol,rectCue1,holdWid);
        Screen('FrameRect',prm.screen.window,prm.pref.CueCol,rectCue2,holdWid);
        Screen('FrameRect',prm.screen.window,prm.pref.CueCol,rectCue3,holdWid);
        Screen('FrameRect',prm.screen.window,prm.pref.CueCol,rectCue4,holdWid);
        
    case 'ColorPatch1of4'
        % draw single color square
        colorSize  = prm.pref.ColSiz * prm.screen.ppd;
        colorEcc   = prm.pref.Eccent * prm.screen.ppd;
        colorR     = prm.regis.colorsquareR;
        
        rectColor1 = [prm.screen.center(1)-colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(2)-colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(1)-colorEcc/sqrt(2)+colorSize/2,...,
            prm.screen.center(2)-colorEcc/sqrt(2)+colorSize/2];
        rectColor2 = [prm.screen.center(1)+colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(2)-colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(1)+colorEcc/sqrt(2)+colorSize/2,...,
            prm.screen.center(2)-colorEcc/sqrt(2)+colorSize/2];
        rectColor3 = [prm.screen.center(1)-colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(2)+colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(1)-colorEcc/sqrt(2)+colorSize/2,...,
            prm.screen.center(2)+colorEcc/sqrt(2)+colorSize/2];
        rectColor4 = [prm.screen.center(1)+colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(2)+colorEcc/sqrt(2)-colorSize/2,...,
            prm.screen.center(1)+colorEcc/sqrt(2)+colorSize/2,...,
            prm.screen.center(2)+colorEcc/sqrt(2)+colorSize/2];
        
        switch prm.regis.rescueposition
            case 1
                Screen('FillRect',prm.screen.window,colorR,rectColor1);
            case 2
                Screen('FillRect',prm.screen.window,colorR,rectColor2);
            case 3
                Screen('FillRect',prm.screen.window,colorR,rectColor3);
            case 4
                Screen('FillRect',prm.screen.window,colorR,rectColor4);
        end
    case 'Distractor1of4'
        % draw single color square
        colorSize  = prm.pref.ColSiz * prm.screen.ppd;
        colorEcc   = prm.pref.Eccent * prm.screen.ppd;
        colorR     = prm.pref.CueCol;
        
        dotSize = prm.pref.FixSiz*prm.screen.ppd;
        rect1centerx = prm.screen.center(1)-colorEcc/sqrt(2);
        rect1centery = prm.screen.center(2)-colorEcc/sqrt(2);
        rectColor1 = CenterRectOnPoint([0 0 colorSize/2 colorSize/2],rect1centerx,rect1centery);
        
        rect2centerx = prm.screen.center(1)+colorEcc/sqrt(2);
        rect2centery = prm.screen.center(2)-colorEcc/sqrt(2);
        rectColor2 = CenterRectOnPoint([0 0 colorSize/2 colorSize/2],rect2centerx,rect2centery);
        
        rect3centerx = prm.screen.center(1)-colorEcc/sqrt(2);
        rect3centery = prm.screen.center(2)+colorEcc/sqrt(2);
        rectColor3 = CenterRectOnPoint([0 0 colorSize/2 colorSize/2],rect3centerx,rect3centery);
        
        rect4centerx = prm.screen.center(1)+colorEcc/sqrt(2);
        rect4centery = prm.screen.center(2)+colorEcc/sqrt(2);
        rectColor4 = CenterRectOnPoint([0 0 colorSize/2 colorSize/2],rect4centerx,rect4centery);
        
        if prm.regis.DistractCueLocation ~= 0
            switch prm.regis.DistractCueLocation
                case 1
                    rectx = rect1centerx; recty = rect1centery;
                case 2
                    rectx = rect2centerx; recty = rect2centery;
                case 3
                    rectx = rect3centerx; recty = rect3centery;
                case 4
                    rectx = rect4centerx; recty = rect4centery;
            end
            dot1 = CenterRectOnPoint([0 0 dotSize dotSize],rectx,recty+colorSize/2+prm.pref.dotDist*prm.screen.ppd);
            dot2 = CenterRectOnPoint([0 0 dotSize dotSize],rectx-colorSize/2-prm.pref.dotDist*prm.screen.ppd,recty);
            dot3 = CenterRectOnPoint([0 0 dotSize dotSize],rectx,recty-colorSize/2-prm.pref.dotDist*prm.screen.ppd);
            dot4 = CenterRectOnPoint([0 0 dotSize dotSize],rectx+colorSize/2+prm.pref.dotDist*prm.screen.ppd,recty);
            Screen('FillOval',prm.screen.window,colorR,dot1);
            Screen('FillOval',prm.screen.window,colorR,dot2);
            Screen('FillOval',prm.screen.window,colorR,dot3);
            Screen('FillOval',prm.screen.window,colorR,dot4);
        else
            
        end
    case 'GrayHolder4'
        % draw gray square holder
        cueSize = prm.pref.CueSiz*prm.screen.ppd;
        cueEcc  = prm.pref.CueEcc*prm.screen.ppd;
        holdWid = prm.pref.HolWid*prm.screen.ppd;
        %  ---------
        % | 1     2 |
        % |         |
        % | 3     4 |
        %  ---------
        
        rectCue1 = [prm.screen.center(1)-cueEcc/sqrt(2)-cueSize/2,...,
            prm.screen.center(2)-cueEcc/sqrt(2)-cueSize/2,...,
            prm.screen.center(1)-cueEcc/sqrt(2)+cueSize/2,...,
            prm.screen.center(2)-cueEcc/sqrt(2)+cueSize/2];
        
        rectCue2 = [prm.screen.center(1)+cueEcc/sqrt(2)-cueSize/2,...,
            prm.screen.center(2)-cueEcc/sqrt(2)-cueSize/2,...,
            prm.screen.center(1)+cueEcc/sqrt(2)+cueSize/2,...,
            prm.screen.center(2)-cueEcc/sqrt(2)+cueSize/2];
        
        rectCue3 = [prm.screen.center(1)-cueEcc/sqrt(2)-cueSize/2,...,
            prm.screen.center(2)+cueEcc/sqrt(2)-cueSize/2,...,
            prm.screen.center(1)-cueEcc/sqrt(2)+cueSize/2,...,
            prm.screen.center(2)+cueEcc/sqrt(2)+cueSize/2];
        
        rectCue4 = [prm.screen.center(1)+cueEcc/sqrt(2)-cueSize/2,...,
            prm.screen.center(2)+cueEcc/sqrt(2)-cueSize/2,...,
            prm.screen.center(1)+cueEcc/sqrt(2)+cueSize/2,...,
            prm.screen.center(2)+cueEcc/sqrt(2)+cueSize/2];
        
        Screen('FrameRect',prm.screen.window,prm.pref.CueColgray,rectCue1,holdWid);
        Screen('FrameRect',prm.screen.window,prm.pref.CueColgray,rectCue2,holdWid);
        Screen('FrameRect',prm.screen.window,prm.pref.CueColgray,rectCue3,holdWid);
        Screen('FrameRect',prm.screen.window,prm.pref.CueColgray,rectCue4,holdWid);
        
end

end
