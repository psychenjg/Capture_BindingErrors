function RunTrials
% display each trial

global prm resp tEYEOn fixout ColSquOn ISI1On ISI2On MaskOn CueOn fixBreak t

resp.ma{prm.regis.nTrial} = [];
resp.mx{prm.regis.nTrial} = [];
resp.my{prm.regis.nTrial} = [];

disp(['trial number = ',num2str(prm.regis.nTrial)])

breakit = 0;

fixBreak = 0;
trialDone = 0;
fixout=1;

CueOn = 0;
ISI1On = 0;
ColSquOn = 0;
ISI2On = 0;
MaskOn = 0;
ResOn = 0;
FeeOn = 0;
ITIOn = 0;
% run this trial in prm.trial structure
prm.trial.sequence(prm.regis.nTrial) = Sample(1:prm.pref.TperB-prm.regis.nTrial+1);
% define prm.regis structure
prm.regis.TargetLocation = prm.trial.TargetLocation(prm.trial.sequence(prm.regis.nTrial));
prm.regis.DistractCueLocation = prm.trial.DistractCueLocation(prm.trial.sequence(prm.regis.nTrial));
prm.regis.colorsquare1(1:3) = prm.RGBcolor(prm.trial.colorIdx(prm.trial.sequence(prm.regis.nTrial),1),1:3);
prm.regis.colorsquare2(1:3) = prm.RGBcolor(prm.trial.colorIdx(prm.trial.sequence(prm.regis.nTrial),2),1:3);
prm.regis.colorsquare3(1:3) = prm.RGBcolor(prm.trial.colorIdx(prm.trial.sequence(prm.regis.nTrial),3),1:3);
prm.regis.colorsquare4(1:3) = prm.RGBcolor(prm.trial.colorIdx(prm.trial.sequence(prm.regis.nTrial),4),1:3);
prm.regis.rotateangle = prm.trial.rotateangle(prm.trial.sequence(prm.regis.nTrial));
prm.regis.cwflip = prm.trial.cwflip(prm.trial.sequence(prm.regis.nTrial));
prm.regis.colortargetIdx = prm.trial.colorIdx(prm.trial.sequence(prm.regis.nTrial),prm.regis.TargetLocation);
prm.regis.colorsquareIdx(1:4) = prm.trial.colorIdx(prm.trial.sequence(prm.regis.nTrial),1:4);
            
%% Trial
% fixation
DrawStimuli('Fixation');
DrawStimuli('Holder3');
resp.tStart(prm.regis.nTrial) = Screen('Flip',prm.screen.window);
t = GetSecs();
tEYEOn = t;
while ~breakit

    if  (~fixout || ~prm.info.EyeTra) && ~CueOn && ((~prm.info.EyeTra && (t-resp.tStart(prm.regis.nTrial))>=prm.pref.FixDur-prm.screen.refresh*0.5)||(t-tEYEOn)>=(prm.pref.FixDur-prm.screen.refresh*0.5))
        % precue
        DrawStimuli('Fixation');
        %DrawStimuli('PreCue4');
        DrawStimuli('Holder4');

        t=GetSecs();
        if t-resp.tStart(prm.regis.nTrial)>=prm.pref.FixDur-prm.screen.refresh*0.5
            if prm.info.EyeTra
            Eyelink('message', 'EVENT_CueOn');
            resp.mx{prm.regis.nTrial}=[resp.mx{prm.regis.nTrial} 99991];
            resp.my{prm.regis.nTrial}=[resp.my{prm.regis.nTrial} 99991];
            resp.ma{prm.regis.nTrial}=[resp.ma{prm.regis.nTrial} 99991];
            end
            resp.cueOnSet(prm.regis.nTrial) = Screen('Flip',prm.screen.window);
            CueOn = 1;
        end
    elseif CueOn && ~ISI1On
        % ISI_1
        DrawStimuli('Fixation');
        DrawStimuli('Holder4');
        t=GetSecs();
        if t-resp.cueOnSet(prm.regis.nTrial)>=prm.pref.CueDur-prm.screen.refresh*0.5
            if prm.info.EyeTra
                Eyelink('message', 'EVENT_ISI1On');
                resp.mx{prm.regis.nTrial}=[resp.mx{prm.regis.nTrial} 99992];
                resp.my{prm.regis.nTrial}=[resp.my{prm.regis.nTrial} 99992];
                resp.ma{prm.regis.nTrial}=[resp.ma{prm.regis.nTrial} 99992];
            end
            resp.ISI1OnSet(prm.regis.nTrial) = Screen('Flip',prm.screen.window);
            ISI1On = 1;
        end
    elseif ISI1On && ~ColSquOn
        % color square
        DrawStimuli('Fixation');
%         DrawStimuli('ColorWheel');
%         DrawStimuli('FeedLine');
        
        DrawStimuli('ColorPatch4');
        DrawStimuli('Distractor1of4');
        DrawStimuli('Holder4');
        DrawStimuli('PreCue4');
        t=GetSecs();
        if t-resp.ISI1OnSet(prm.regis.nTrial)>=prm.pref.ISI1-prm.screen.refresh*0.5
            if prm.info.EyeTra
                Eyelink('message', 'EVENT_ColSquOn');
                resp.mx{prm.regis.nTrial}=[resp.mx{prm.regis.nTrial} 99993];
                resp.my{prm.regis.nTrial}=[resp.my{prm.regis.nTrial} 99993];
                resp.ma{prm.regis.nTrial}=[resp.ma{prm.regis.nTrial} 99993];
            end
            resp.ColSquOnSet(prm.regis.nTrial) = Screen('Flip',prm.screen.window);
            ColSquOn = 1;
        end
    elseif ColSquOn && ~ISI2On 
        % ISI_2
        DrawStimuli('Fixation');
        t=GetSecs();
        if t-resp.ColSquOnSet(prm.regis.nTrial)>=prm.pref.CorDur-prm.screen.refresh*0.5
            if prm.info.EyeTra
                Eyelink('message', 'EVENT_ISI2On');
                resp.mx{prm.regis.nTrial}=[resp.mx{prm.regis.nTrial} 99994];
                resp.my{prm.regis.nTrial}=[resp.my{prm.regis.nTrial} 99994];
                resp.ma{prm.regis.nTrial}=[resp.ma{prm.regis.nTrial} 99994];
            end
            resp.ISI2OnSet(prm.regis.nTrial) = Screen('Flip',prm.screen.window);
            ISI2On = 1;
        end
    elseif ISI2On && ~MaskOn 
        % mask
        DrawStimuli('Fixation');
        DrawStimuli('Mask4');
        DrawStimuli('Holder4');
        t=GetSecs();
        if t-resp.ISI2OnSet(prm.regis.nTrial)>=prm.pref.ISI2-prm.screen.refresh*0.5
            if prm.info.EyeTra
                Eyelink('message', 'EVENT_MaskOn');
                resp.mx{prm.regis.nTrial}=[resp.mx{prm.regis.nTrial} 99995];
                resp.my{prm.regis.nTrial}=[resp.my{prm.regis.nTrial} 99995];
                resp.ma{prm.regis.nTrial}=[resp.ma{prm.regis.nTrial} 99995];
            end
            resp.MaskOnSet(prm.regis.nTrial) = Screen('Flip',prm.screen.window);
            MaskOn = 1;
        end
    elseif MaskOn && ~ResOn 
        % response
        DrawStimuli('Fixation');
        DrawStimuli('ColorWheel');
        DrawStimuli('RespCue4');
        t=GetSecs();
        if t-resp.MaskOnSet(prm.regis.nTrial)>=prm.pref.MasDur-prm.screen.refresh*0.5
            if prm.info.EyeTra
                Eyelink('message', 'EVENT_ResOn');
                resp.mx{prm.regis.nTrial}=[resp.mx{prm.regis.nTrial} 99996];
                resp.my{prm.regis.nTrial}=[resp.my{prm.regis.nTrial} 99996];
                resp.ma{prm.regis.nTrial}=[resp.ma{prm.regis.nTrial} 99996];
            end
            resp.ResOnSet(prm.regis.nTrial) = Screen('Flip',prm.screen.window,resp.MaskOnSet(prm.regis.nTrial)+prm.pref.MasDur-prm.screen.refresh*0.5);
            
            % get response
            SetMouse(prm.screen.center(1),prm.screen.center(2),prm.screen.window);
            for i = 1:100
                ShowCursor('CrossHair');
            end
            [getx,gety,buttons] = GetMouse(prm.screen.window);
            buttons = 0;
            % click 1, report color
            clickedcolor = 0;
            while clickedcolor == 0
                fixCheck;
                [getx,gety,buttons] = GetMouse(prm.screen.window);
                r = sqrt((getx-prm.screen.center(1))^2+(gety-prm.screen.center(2))^2);
                if r<=prm.pref.MaxRad*prm.screen.ppd && r>=prm.pref.MinRad*prm.screen.ppd
                    prm.regis.colorsquareRIdx = GetColorIdx(getx,gety,prm.regis.rotateangle,prm.regis.cwflip);
                    prm.regis.colorsquareR = prm.RGBcolor(prm.regis.colorsquareRIdx,1:3);
                    if buttons(1)
                        resp.RT(prm.regis.nTrial)=GetSecs- resp.ResOnSet(prm.regis.nTrial);
                        resp.click.x(prm.regis.nTrial) = getx;
                        resp.click.y(prm.regis.nTrial) = gety;
                        resp.click.colorIdx(prm.regis.nTrial) = GetColorIdx(getx,gety,prm.regis.rotateangle,prm.regis.cwflip);
                        resp.click.color(prm.regis.nTrial,1:3) = prm.RGBcolor(resp.click.colorIdx(prm.regis.nTrial),1:3);
                        clickedcolor = 1;
                        
                        DrawStimuli('Fixation');
                        DrawStimuli('ColorWheel');
                        DrawStimuli('RespCue4');
                        prm.regis.currentColor = resp.click.colorIdx(prm.regis.nTrial);
                        DrawStimuli('Line');
                        
                        resp.clickcolor(prm.regis.nTrial) = Screen('Flip',prm.screen.window);
                        while buttons(1)
                            [getx,gety,buttons] = GetMouse(prm.screen.window);
                        end
                        
                    end
                end
                
            end
            reportrange = 0;
            while reportrange == 0
                % click 2, report start point
                clickedcolorrange1 = 0;
                while clickedcolorrange1 == 0
                    fixCheck;
                    [getx,gety,buttons] = GetMouse(prm.screen.window);
                    r = sqrt((getx-prm.screen.center(1))^2+(gety-prm.screen.center(2))^2);
                    if r<=prm.pref.MaxRad*prm.screen.ppd && r>=prm.pref.MinRad*prm.screen.ppd
                        prm.regis.currentColor = GetColorIdx(getx,gety,prm.regis.rotateangle,prm.regis.cwflip);
                        if buttons(1)
                            resp.clickrange1RT(prm.regis.nTrial)=GetSecs-resp.ResOnSet(prm.regis.nTrial)-resp.RT(prm.regis.nTrial);
                            resp.clickrange1.x(prm.regis.nTrial) = getx;
                            resp.clickrange1.y(prm.regis.nTrial) = gety;
                            resp.clickrange1.colorIdx(prm.regis.nTrial) = GetColorIdx(getx,gety,prm.regis.rotateangle,prm.regis.cwflip);
                            resp.clickrange1.color(prm.regis.nTrial,1:3) = prm.RGBcolor(resp.click.colorIdx(prm.regis.nTrial),1:3);
                            clickedcolorrange1 = 1;
                            DrawStimuli('Fixation');
                            
                            prm.regis.currentColor = resp.click.colorIdx(prm.regis.nTrial);
                            DrawStimuli('Line');
                            
                            DrawStimuli('ColorWheel');
                            DrawStimuli('RespCue4');
                            resp.click1Onset(prm.regis.nTrial) = Screen('Flip',prm.screen.window);
                            
                            while buttons(1)
                                [getx,gety,buttons] = GetMouse(prm.screen.window);
                            end
                            
                        end
                    end
                end
                % click 3, report end point
                clickedcolorrange2 = 0;
                while clickedcolorrange2 == 0
                    fixCheck;
                    [getx,gety,buttons] = GetMouse(prm.screen.window);
                    r = sqrt((getx-prm.screen.center(1))^2+(gety-prm.screen.center(2))^2);
                    if r<=prm.pref.MaxRad*prm.screen.ppd && r>=prm.pref.MinRad*prm.screen.ppd
                        
                        prm.regis.currentColor = GetColorIdx(getx,gety,prm.regis.rotateangle,prm.regis.cwflip);
                        
                        DrawStimuli('Fixation');

                        DrawStimuli('ColorWheel');
                        DrawStimuli('ShadedOval');
                        DrawStimuli('RespCue4');
                        prm.regis.currentColor = resp.click.colorIdx(prm.regis.nTrial);
                        DrawStimuli('Line');
                        Screen('Flip',prm.screen.window);
                        if buttons(2)
                            clickedcolorrange1 = 0;
                            DrawStimuli('Fixation');            
                            DrawStimuli('ColorWheel');
                            DrawStimuli('RespCue4');
                            prm.regis.currentColor = resp.click.colorIdx(prm.regis.nTrial);
                            DrawStimuli('Line');
                            Screen('Flip',prm.screen.window);
                            break
                        end
                        if buttons(1)
                            resp.clickrange2RT(prm.regis.nTrial)=GetSecs-resp.ResOnSet(prm.regis.nTrial)-resp.clickrange1RT(prm.regis.nTrial)-resp.RT(prm.regis.nTrial);
                            resp.clickrange2.x(prm.regis.nTrial) = getx;
                            resp.clickrange2.y(prm.regis.nTrial) = gety;
                            resp.clickrange2.colorIdx(prm.regis.nTrial) = GetColorIdx(getx,gety,prm.regis.rotateangle,prm.regis.cwflip);
                            resp.clickrange2.color(prm.regis.nTrial,1:3) = prm.RGBcolor(resp.click.colorIdx(prm.regis.nTrial),1:3);
                            clickedcolorrange2 = 1;
                            reportrange = 1;
                            
%                             DrawStimuli('Fixation');
%                             DrawStimuli('RespCue4');
%                             prm.regis.currentColor = resp.click.colorIdx(prm.regis.nTrial);
%                             DrawStimuli('Line');
%                             DrawStimuli('ColorWheel');
%                             resp.click2Onset(prm.regis.nTrial) = Screen('Flip',prm.screen.window);
                            
                            while buttons(1)
                                [getx,gety,buttons] = GetMouse(prm.screen.window);
                            end
                        end
                    end
                end
            end
            DrawStimuli('Fixation');
            DrawStimuli('ColorWheel');
            DrawStimuli('RespCue4');
            resp.ClickEnd(prm.regis.nTrial) = Screen('Flip',prm.screen.window);
            HideCursor;
            
            WaitSecs(0.5);
            ResOn = 1;
        end
    elseif ResOn && ~FeeOn
        % feedback
        DrawStimuli('Fixation');
        DrawStimuli('RespCue4');
        DrawStimuli('ColorWheel');
        DrawStimuli('FeedLine');
        if prm.info.EyeTra
            Eyelink('message', 'EVENT_FeeOn');
            resp.mx{prm.regis.nTrial}=[resp.mx{prm.regis.nTrial} 99997];
            resp.my{prm.regis.nTrial}=[resp.my{prm.regis.nTrial} 99997];
            resp.ma{prm.regis.nTrial}=[resp.ma{prm.regis.nTrial} 99997];
        end
        resp.FeedOnSet(prm.regis.nTrial) = Screen('Flip',prm.screen.window);
        FeeOn = 1;
    elseif FeeOn && ~ITIOn
        t = GetSecs();
        if t-resp.FeedOnSet(prm.regis.nTrial)>=prm.pref.FeeDur--prm.screen.refresh*0.5
            if prm.info.EyeTra
                Eyelink('message', 'EVENT_ITIOn');
                resp.mx{prm.regis.nTrial}=[resp.mx{prm.regis.nTrial} 99998];
                resp.my{prm.regis.nTrial}=[resp.my{prm.regis.nTrial} 99998];
                resp.ma{prm.regis.nTrial}=[resp.ma{prm.regis.nTrial} 99998];
            end
            trialDone = 1;
            resp.ITIOnSet(prm.regis.nTrial) = Screen('Flip',prm.screen.window);
            WaitSecs(prm.pref.ITI);
            ITIOn = 1;
        end
    end
    t = GetSecs();
    [~, ~, keycode] = KbCheck(-1);
    if keycode(prm.pref.quitkey)
        breakit = 3;
    end 
    
    % fixation loss exam
    fixCheck;
    
    
    if trialDone
        breakit = 1;
    elseif fixBreak && ~trialDone
        breakit = 2;
        prm.fixbreakcount = prm.fixbreakcount+1;
    end
    
end
switch breakit
    case 1
        prm.done = 1;
        
        resp.trial.sequence(prm.regis.nTrial) = prm.trial.sequence(prm.regis.nTrial);
        resp.trial.TargetLocation(prm.regis.nTrial) = prm.regis.TargetLocation;
        resp.trial.DistractCueLocation(prm.regis.nTrial) = prm.regis.DistractCueLocation;
        resp.trial.colorsquare1(prm.regis.nTrial,1:3) = prm.regis.colorsquare1(1:3);
        resp.trial.colorsquare2(prm.regis.nTrial,1:3) = prm.regis.colorsquare2(1:3);
        resp.trial.colorsquare3(prm.regis.nTrial,1:3) = prm.regis.colorsquare3(1:3);
        resp.trial.colorsquare4(prm.regis.nTrial,1:3) = prm.regis.colorsquare4(1:3);
        resp.trial.rotateangle(prm.regis.nTrial) = prm.regis.rotateangle;
        resp.trial.cwflip(prm.regis.nTrial) = prm.regis.cwflip;
        resp.trial.colortargetIdx(prm.regis.nTrial) = prm.regis.colortargetIdx;
        resp.trial.colorsquareIdx(prm.regis.nTrial,1:4) = prm.regis.colorsquareIdx(1:4);
        
        prm.trial.TargetLocation(prm.trial.sequence(prm.regis.nTrial)) = [];
        prm.trial.DistractCueLocation(prm.trial.sequence(prm.regis.nTrial)) = [];
        prm.trial.colorIdx(prm.trial.sequence(prm.regis.nTrial),:) = [];
        prm.trial.rotateangle(prm.trial.sequence(prm.regis.nTrial)) = [];
        prm.trial.cwflip(prm.trial.sequence(prm.regis.nTrial)) = [];

        save(prm.filename.prm,'prm');
        save(prm.filename.resp,'resp');
        fprintf(prm.file.resptxt,'%d\t',prm.regis.TargetLocation);
        fprintf(prm.file.resptxt,'%d\t',prm.regis.DistractCueLocation);
        fprintf(prm.file.resptxt,'%d %d %d\t',prm.regis.colorsquare1(1:3));
        fprintf(prm.file.resptxt,'%d %d %d\t',prm.regis.colorsquare2(1:3));
        fprintf(prm.file.resptxt,'%d %d %d\t',prm.regis.colorsquare3(1:3));
        fprintf(prm.file.resptxt,'%d %d %d\t',prm.regis.colorsquare4(1:3));
        fprintf(prm.file.resptxt,'%d\t',prm.regis.rotateangle);
        fprintf(prm.file.resptxt,'%d\t',prm.regis.cwflip);
        fprintf(prm.file.resptxt,'%d\t',prm.regis.colortargetIdx);
        fprintf(prm.file.resptxt,'%d %d %d %d\t\n',prm.regis.colorsquareIdx(1:4));

    case 2
        if prm.fixbreakcount> prm.pref.fixlosscount_thresh
            prm.fixbreakcount = 0;
            disp('Calibration')
            EyelinkSetup(1) % no initialize
        end
        Screen('Flip',prm.screen.window);
        Beeper(500,100,0.05);
        DrawFormattedText(prm.screen.window,'Fixation error','center','center',255);
        Screen('Flip',prm.screen.window);
        WaitSecs(0.2);
        Screen('Flip',prm.screen.window);
        WaitSecs(0.3);
    case 3
        sca;
        if prm.info.EyeTra
            Eyelink('stoprecording');
            Eyelink('closefile');
            Eyelink('Shutdown');
        end
        ListenChar;
        error 'User Quit';
end


end


