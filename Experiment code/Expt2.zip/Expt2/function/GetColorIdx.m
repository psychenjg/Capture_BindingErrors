function colorIdx = GetColorIdx(x,y,rotateangle,cwflip)
% get color index from cursor position relative to center (x,y)

global prm

%
%           1.5pi
%           .   .
%         .       .
%       .           .
%   p  .             . 2pi
%      .             .  0
%       .           .
%         .       .
%           .   .
%           0.5pi
%
% ***** connection with atan2(y,x) *****
% angle = mod(2*pi - atan2,2pi)
% ***** colorRGB matrix *****
% colorRGB ( ceil(angle*90/pi) )
% Notice: per color obtain the angle of "pi/90"
% *************************************************************************
% from     1         to        180        in RGBmatrix, corresponding to:
% from [0,pi/90) to [179*pi/90,180*pi/90] in color wheel


centerx = prm.screen.center(1);
centery = prm.screen.center(2);

if ~cwflip
    angle = mod(2*pi-atan2(centery-y,x-centerx)-rotateangle/180*pi,2*pi);
    colorIdx = ceil(angle*90/pi);
    colorIdx = mod(colorIdx,180);
else
    angle = mod(atan2(centery-y,x-centerx)+rotateangle/180*pi,2*pi);
    colorIdx = ceil(angle*90/pi);
    colorIdx = mod(colorIdx,180);
end
if colorIdx == 0
    colorIdx = 180;
end
end