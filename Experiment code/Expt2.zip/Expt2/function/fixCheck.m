function fixCheck()
global resp prm tEYEOn fixout ColSquOn ISI1On ISI2On MaskOn CueOn fixBreak el t
if prm.info.EyeTra 
        errormes=Eyelink('CheckRecording');
        if(errormes~=0)
        end
        if Eyelink('NewFloatSampleAvailable') > 0
            % get the sample in the form of an event structure
            evt = Eyelink( 'NewestFloatSample');
            x = evt.gx(evt.gx~=el.MISSING_DATA);
            y = evt.gy(evt.gy~=el.MISSING_DATA);
            a = evt.pa(evt.pa~=-el.MISSING_DATA);
            resp.mx{prm.regis.nTrial}=[resp.mx{prm.regis.nTrial} x];
            resp.my{prm.regis.nTrial}=[resp.my{prm.regis.nTrial} y];
            resp.ma{prm.regis.nTrial}=[resp.ma{prm.regis.nTrial} a];
            % check whether fix the center
            if ~ (isempty(x) || isempty(y) || isempty(a))
                if x~=el.MISSING_DATA && y~=el.MISSING_DATA && a>0 % do we have valid data and is the pupil visible?
                    dist_from_fix = round(( (x-prm.screen.center(1))^2 + (y-prm.screen.center(2))^2 ) ^ (1/2));
                    if dist_from_fix > round(prm.pref.fixlossradVA * prm.screen.ppd)
                        fixout = 1;
                    else
                        if fixout == 1
                            tEYEOn = GetSecs(); % record the "start to fix" time
                        end
                        fixout = 0;
                    end
                end
            else
                fixout = 1;
            end
            
            
            if ( ~ColSquOn || ~ISI1On || ~ISI2On || ~MaskOn) && CueOn
                if fixout == 1
                    fixBreak = 1;
                end
            elseif ~CueOn && t>(resp.tStart(prm.regis.nTrial)+prm.pref.max_prefix_time)
                if fixout == 1
                    fixBreak = 1;
                end
            else
                fixBreak = 0;
            end
        end
    else
        fixBreak=0;
end

end